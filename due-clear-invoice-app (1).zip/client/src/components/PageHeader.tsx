import { Link } from "wouter";
import { FaCheckSquare } from "react-icons/fa";

export default function PageHeader() {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FaCheckSquare className="text-teal-500 text-xl" />
          <span className="text-xl font-semibold text-slate-700">
            <span className="text-teal-500">Due</span> Clear
          </span>
        </div>
        <nav>
          <ul className="flex space-x-8">
            <li>
              <Link href="/">
                <a className="text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors">
                  Home
                </a>
              </Link>
            </li>
            <li>
              <Link href="#">
                <a className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors">
                  Invoicing Guide
                </a>
              </Link>
            </li>
            <li>
              <Link href="#">
                <a className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors">
                  Help
                </a>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
