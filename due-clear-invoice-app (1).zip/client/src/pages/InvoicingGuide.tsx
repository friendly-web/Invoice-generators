import React from 'react';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageHeader from '@/components/PageHeader';
import PageFooter from '@/components/PageFooter';

export default function InvoicingGuide() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageHeader />
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-900">Complete Invoicing Guide</h1>
        
        <div className="prose prose-lg max-w-none">
          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4" id="what-is-invoice">What is an Invoice?</h2>
            <p>
              An invoice is a commercial document issued by a seller to a buyer that indicates the products, quantities, 
              and agreed prices for products or services the seller has provided. It serves as a request for payment and 
              becomes a legal document once both parties agree to the terms.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4" id="invoice-elements">Essential Elements of a Professional Invoice</h2>
            <p>
              Creating a comprehensive invoice ensures clear communication and timely payments. Here are the key components 
              every professional invoice should include:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Business Information:</strong> Your company name, logo, address, contact details, and tax ID numbers.</li>
              <li><strong>Client Information:</strong> Your client's business name, contact person, and complete address.</li>
              <li><strong>Invoice Details:</strong> Unique invoice number, issue date, and payment due date.</li>
              <li><strong>Itemized List of Services/Products:</strong> Detailed description of services provided or products sold, 
                including quantity, rate, and total amount for each item.</li>
              <li><strong>Payment Terms:</strong> Clear information about when payment is expected (e.g., due upon receipt, Net 30).</li>
              <li><strong>Payment Methods:</strong> How clients can pay you (bank transfer, PayPal, credit card, etc.).</li>
              <li><strong>Subtotal, Taxes, and Total Amount:</strong> Breakdown of costs before taxes, applicable tax amounts, and the final total.</li>
              <li><strong>Additional Notes:</strong> Any special payment terms, late payment policies, or thank you message.</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4" id="invoice-tips">Best Practices for Effective Invoicing</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-medium mb-2">Be Prompt with Your Invoices</h3>
                <p>
                  Send invoices immediately after delivering your product or service. Delayed invoicing can lead to delayed 
                  payments and cash flow issues.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-medium mb-2">Use Clear, Professional Language</h3>
                <p>
                  Avoid jargon and be specific about the services provided. Use professional language that clearly communicates 
                  what you're billing for.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-medium mb-2">Set Clear Payment Terms</h3>
                <p>
                  Clearly state when payment is expected and offer multiple payment options to make it easier for clients to pay you.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-medium mb-2">Implement Numbering System</h3>
                <p>
                  Use a consistent invoice numbering system that helps you track invoices easily and allows clients to reference 
                  specific invoices when making payments.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-medium mb-2">Follow Up on Overdue Payments</h3>
                <p>
                  Have a system for tracking unpaid invoices and send polite reminders when payments become overdue.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-medium mb-2">Keep Records</h3>
                <p>
                  Maintain copies of all invoices for your records and tax purposes. Our system automatically stores your invoice history.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4" id="invoice-templates">Why Use Invoice Templates?</h2>
            <p>
              Using professionally designed invoice templates offers several advantages:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Time Efficiency:</strong> Create invoices quickly without starting from scratch each time.</li>
              <li><strong>Consistency:</strong> Maintain a consistent, professional look across all your billing documents.</li>
              <li><strong>Professionalism:</strong> Present your business in the best light with well-designed documents.</li>
              <li><strong>Completeness:</strong> Ensure you never miss important details with pre-formatted sections for all essential information.</li>
              <li><strong>Brand Reinforcement:</strong> Add your logo and use your brand colors to strengthen brand recognition.</li>
            </ul>
            <p className="mt-4">
              Due Clear's invoice generator provides professional templates that include all necessary components, saving you time 
              and ensuring your invoices look professional every time.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4" id="invoice-legal">Legal Aspects of Invoicing</h2>
            <p>
              Invoices are more than just payment requests—they're legal documents with implications for taxes and business records.
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Tax Requirements:</strong> In most jurisdictions, invoices must include specific information for tax purposes, 
                such as tax registration numbers, tax amounts, and dates.</li>
              <li><strong>Record Keeping:</strong> Businesses are typically required to keep copies of invoices for several years for tax audits.</li>
              <li><strong>Payment Terms Enforcement:</strong> A properly documented invoice helps enforce payment terms if disputes arise.</li>
            </ul>
            <p className="mt-4">
              Always consult with a financial advisor or accountant to ensure your invoicing practices comply with local regulations.
            </p>
          </section>
        </div>

        <div className="mt-12 text-center">
          <p className="text-xl mb-6">Ready to create professional invoices in minutes?</p>
          <Link href="/invoice/create">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 text-lg">
              Create Your Invoice Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </main>
      
      <PageFooter />
    </div>
  );
}