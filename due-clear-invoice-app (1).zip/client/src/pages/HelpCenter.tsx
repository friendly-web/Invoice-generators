import React from 'react';
import { Link } from 'wouter';
import { Search } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import PageFooter from '@/components/PageFooter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function HelpCenter() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageHeader />
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center text-gray-900">Help Center</h1>
        
        <div className="bg-blue-50 rounded-lg p-8 mb-12">
          <h2 className="text-2xl font-semibold mb-4 text-center">How can we help you today?</h2>
          <div className="flex max-w-xl mx-auto">
            <Input 
              placeholder="Search for help articles..." 
              className="rounded-r-none border-r-0 focus-visible:ring-0 focus-visible:ring-offset-0" 
            />
            <Button className="rounded-l-none bg-blue-600 hover:bg-blue-700">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-3">Getting Started</h3>
            <p className="text-gray-600 mb-4">New to Due Clear? Learn the basics of creating your first invoice.</p>
            <ul className="space-y-2 text-blue-600">
              <li>
                <Link href="/help-center/create-first-invoice" className="hover:underline">How to create your first invoice</Link>
              </li>
              <li>
                <Link href="/help-center/customize-invoice" className="hover:underline">Customizing your invoice</Link>
              </li>
              <li>
                <Link href="/help-center/invoice-settings" className="hover:underline">Understanding invoice settings</Link>
              </li>
            </ul>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-3">Managing Invoices</h3>
            <p className="text-gray-600 mb-4">Learn how to manage, track, and organize your invoices effectively.</p>
            <ul className="space-y-2 text-blue-600">
              <li>
                <Link href="/help-center/edit-invoice" className="hover:underline">Editing existing invoices</Link>
              </li>
              <li>
                <Link href="/help-center/download-pdf" className="hover:underline">Downloading invoice PDFs</Link>
              </li>
              <li>
                <Link href="/help-center/invoice-history" className="hover:underline">Viewing invoice history</Link>
              </li>
            </ul>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-3">Payment Options</h3>
            <p className="text-gray-600 mb-4">Configure different payment methods for your clients.</p>
            <ul className="space-y-2 text-blue-600">
              <li>
                <Link href="/help-center/bank-transfers" className="hover:underline">Setting up bank transfer details</Link>
              </li>
              <li>
                <Link href="/help-center/paypal-integration" className="hover:underline">Using PayPal for invoice payments</Link>
              </li>
              <li>
                <Link href="/help-center/payment-methods" className="hover:underline">Other payment methods</Link>
              </li>
            </ul>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-3">Email & Sharing</h3>
            <p className="text-gray-600 mb-4">Learn how to send invoices directly to your clients.</p>
            <ul className="space-y-2 text-blue-600">
              <li>
                <Link href="/help-center/email-invoice" className="hover:underline">Emailing invoices to clients</Link>
              </li>
              <li>
                <Link href="/help-center/invoice-links" className="hover:underline">Sharing invoice links</Link>
              </li>
              <li>
                <Link href="/help-center/email-templates" className="hover:underline">Customizing email templates</Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">Frequently Asked Questions</h2>
          
          <Accordion type="single" collapsible className="border rounded-md">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-left px-4">Is Due Clear completely free to use?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                Yes, Due Clear is completely free to use. You can create unlimited invoices, download PDFs, and email invoices 
                to clients without any hidden charges or premium tiers.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger className="text-left px-4">Do I need to create an account to use Due Clear?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                No, you don't need to create an account to generate and download invoices. However, creating an account 
                allows you to save your invoice history and access them later.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger className="text-left px-4">How do I add my logo to invoices?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                When creating an invoice, you'll see a logo upload section at the top of the form. Click on it to upload 
                your company logo, which will appear on the generated invoice.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger className="text-left px-4">Can I customize the invoice number format?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                Currently, Due Clear automatically generates invoice numbers in a standard format (INV-XXXX). 
                We're working on adding custom invoice number formatting in a future update.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger className="text-left px-4">How do I send invoices to my clients?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                After creating an invoice, you can either download it as a PDF and send it yourself, or use our built-in 
                email feature to send it directly to your client's email address from within Due Clear.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-6">
              <AccordionTrigger className="text-left px-4">Is my data secure with Due Clear?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                Yes, we take data security seriously. Due Clear uses encrypted connections and secure data storage. 
                We don't share your data with third parties. For more details, please refer to our Privacy Policy.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-7">
              <AccordionTrigger className="text-left px-4">Can I track whether clients have viewed my invoices?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                Currently, Due Clear doesn't offer tracking of invoice views. However, when using our email feature, 
                you'll receive a confirmation when the email is sent successfully.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-8">
              <AccordionTrigger className="text-left px-4">How do I handle recurring invoices?</AccordionTrigger>
              <AccordionContent className="px-4 text-gray-600">
                For recurring invoices, you can duplicate an existing invoice and update the dates and other details as needed. 
                We're planning to add automated recurring invoice functionality in the future.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>

        <div className="bg-gray-50 p-8 rounded-lg text-center">
          <h2 className="text-2xl font-semibold mb-4">Still Need Help?</h2>
          <p className="text-gray-600 mb-6">Can't find the answer you're looking for? Feel free to contact our support team.</p>
          <Link href="/contact">
            <Button className="bg-blue-600 hover:bg-blue-700">Contact Support</Button>
          </Link>
        </div>
      </main>
      
      <PageFooter />
    </div>
  );
}