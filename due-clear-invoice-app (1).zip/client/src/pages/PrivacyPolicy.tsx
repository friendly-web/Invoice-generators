import React from 'react';
import PageHeader from '@/components/PageHeader';
import PageFooter from '@/components/PageFooter';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageHeader />
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-900">Privacy Policy</h1>
        
        <div className="prose prose-lg max-w-none">
          <p className="text-gray-600">Last Updated: April 28, 2025</p>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">1. Introduction</h2>
            <p>
              At Due Clear, we respect your privacy and are committed to protecting your personal data. This Privacy Policy 
              explains how we collect, use, disclose, and safeguard your information when you use our invoice generator service.
            </p>
            <p>
              Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please do not 
              access the Service.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">2. Information We Collect</h2>
            <p>
              We collect information that you provide directly to us when using the Service:
            </p>
            <h3 className="text-xl font-medium mb-2 mt-6">2.1 Personal Information</h3>
            <p>
              When you create an account or use our Service, we may collect the following types of personal information:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Account Information:</strong> Such as your name, email address, and password.</li>
              <li><strong>Business Information:</strong> Such as your business name, address, tax identification numbers, 
                logo, and contact details that you include in your invoices.</li>
              <li><strong>Client Information:</strong> Information about your clients that you enter when creating invoices, 
                such as client names, addresses, and contact details.</li>
              <li><strong>Payment Information:</strong> Such as bank account details, PayPal IDs, or other payment method 
                information you include in your invoices.</li>
            </ul>

            <h3 className="text-xl font-medium mb-2 mt-6">2.2 Usage Information</h3>
            <p>
              We automatically collect certain information about your device and how you interact with our Service:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Device Information:</strong> Such as your IP address, browser type, operating system, and device identifiers.</li>
              <li><strong>Usage Data:</strong> Information about your interactions with the Service, such as the pages you visit, 
                features you use, and the time spent on the Service.</li>
              <li><strong>Log Data:</strong> Server logs, which may include information like your IP address, browser type, 
                referring/exit pages, operating system, date/time stamps, and clickstream data.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">3. How We Use Your Information</h2>
            <p>
              We use the information we collect for various purposes, including:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Providing the Service:</strong> To create and manage your account, generate invoices, process payments, 
                and provide customer support.</li>
              <li><strong>Improving the Service:</strong> To analyze usage patterns, diagnose technical problems, and enhance 
                the functionality and user experience of our Service.</li>
              <li><strong>Communications:</strong> To respond to your inquiries, send service-related announcements, and provide updates 
                about our Service.</li>
              <li><strong>Security:</strong> To protect our Service, prevent fraud, and ensure the security of your account and information.</li>
              <li><strong>Legal Compliance:</strong> To comply with applicable laws, regulations, legal processes, or governmental requests.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">4. How We Share Your Information</h2>
            <p>
              We may share your information in the following circumstances:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Service Providers:</strong> We may share your information with third-party service providers who perform 
                services on our behalf, such as hosting, analytics, customer service, email delivery, and database management.</li>
              <li><strong>Business Transfers:</strong> If we are involved in a merger, acquisition, or sale of all or a portion of our 
                assets, your information may be transferred as part of that transaction.</li>
              <li><strong>Legal Requirements:</strong> We may disclose your information if required to do so by law or in response to 
                valid requests by public authorities.</li>
              <li><strong>Protection of Rights:</strong> We may disclose your information to protect the safety, rights, or property of 
                Due Clear, our users, or others.</li>
            </ul>
            <p className="mt-4">
              We do not sell your personal information to third parties.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">5. Data Security</h2>
            <p>
              We implement appropriate technical and organizational measures to protect the security of your personal information. 
              However, please be aware that no method of transmission over the Internet or method of electronic storage is 100% secure.
            </p>
            <p>
              While we strive to use commercially acceptable means to protect your personal information, we cannot guarantee its 
              absolute security. You are responsible for maintaining the secrecy of your unique password and account information.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">6. Your Data Protection Rights</h2>
            <p>
              Depending on your location, you may have certain rights regarding your personal information:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Access:</strong> You may request access to your personal information that we hold.</li>
              <li><strong>Correction:</strong> You may request that we correct any inaccurate or incomplete personal information.</li>
              <li><strong>Deletion:</strong> You may request that we delete your personal information, subject to certain exceptions.</li>
              <li><strong>Restriction:</strong> You may request that we restrict the processing of your personal information.</li>
              <li><strong>Portability:</strong> You may request a copy of your personal information in a structured, commonly used, 
                and machine-readable format.</li>
              <li><strong>Objection:</strong> You may object to our processing of your personal information.</li>
            </ul>
            <p className="mt-4">
              To exercise any of these rights, please contact us using the contact information provided at the end of this Privacy Policy.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">7. Cookies and Similar Technologies</h2>
            <p>
              We use cookies and similar tracking technologies to collect information about your browsing activities on our Service. 
              Cookies are small text files that are stored on your device when you visit a website.
            </p>
            <p>
              We use cookies for various purposes, including:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Essential Cookies:</strong> These cookies are necessary for the Service to function properly and cannot be 
                switched off in our systems.</li>
              <li><strong>Analytical/Performance Cookies:</strong> These cookies allow us to recognize and count the number of visitors 
                and to see how visitors move around our Service when they are using it.</li>
              <li><strong>Functionality Cookies:</strong> These cookies enable the Service to provide enhanced functionality and personalization.</li>
            </ul>
            <p className="mt-4">
              You can set your browser to refuse all or some browser cookies, or to alert you when cookies are being sent. However, 
              if you disable or refuse cookies, please note that some parts of the Service may be inaccessible or not function properly.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">8. Children's Privacy</h2>
            <p>
              Our Service is not directed to individuals under the age of 16. We do not knowingly collect personal information from 
              children under 16. If you are a parent or guardian and you are aware that your child has provided us with personal 
              information, please contact us. If we become aware that we have collected personal information from a child under 16 
              without verification of parental consent, we take steps to remove that information from our servers.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">9. Changes to This Privacy Policy</h2>
            <p>
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy 
              on this page and updating the "Last Updated" date at the top of this Privacy Policy.
            </p>
            <p>
              You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective 
              when they are posted on this page.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">10. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact us at:
            </p>
            <p>
              Email: privacy@dueclear.com<br />
              Address: 123 Invoice Street, Suite 456, Billing City, BC 78901
            </p>
          </section>
        </div>
      </main>
      
      <PageFooter />
    </div>
  );
}