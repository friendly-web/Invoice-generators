import React from 'react';
import PageHeader from '@/components/PageHeader';
import PageFooter from '@/components/PageFooter';

export default function TermsOfService() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageHeader />
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-gray-900">Terms of Service</h1>
        
        <div className="prose prose-lg max-w-none">
          <p className="text-gray-600">Last Updated: April 28, 2025</p>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">1. Introduction</h2>
            <p>
              Welcome to Due Clear ("we," "our," or "us"). These Terms of Service ("Terms") govern your access to and use of 
              the Due Clear website, services, and applications (collectively, the "Service").
            </p>
            <p>
              By accessing or using the Service, you agree to be bound by these Terms. If you do not agree to these Terms, 
              please do not access or use the Service.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">2. Use of the Service</h2>
            <p>
              Due Clear provides an online platform that allows users to create, manage, and send professional invoices. 
              You may use our Service only for lawful purposes and in accordance with these Terms.
            </p>
            <p>
              You agree not to use the Service:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li>In any way that violates any applicable federal, state, local, or international law or regulation.</li>
              <li>To transmit, or procure the sending of, any advertising or promotional material, including any "junk mail," 
                "chain letter," or "spam."</li>
              <li>To impersonate or attempt to impersonate Due Clear, a Due Clear employee, another user, or any other person or entity.</li>
              <li>To engage in any other conduct that restricts or inhibits anyone's use or enjoyment of the Service, or which 
                may harm Due Clear or users of the Service.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">3. User Accounts</h2>
            <p>
              When you create an account with us, you must provide accurate, complete, and current information. You are responsible 
              for safeguarding your account and for all activities that occur under your account.
            </p>
            <p>
              You agree to notify us immediately of any unauthorized access to or use of your user account or password. We cannot 
              and will not be liable for any loss or damage arising from your failure to comply with this section.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">4. Intellectual Property Rights</h2>
            <p>
              The Service and its contents, features, and functionality (including but not limited to all information, software, 
              text, displays, images, video, and audio, and the design, selection, and arrangement thereof) are owned by Due Clear, 
              its licensors, or other providers of such material and are protected by copyright, trademark, patent, trade secret, 
              and other intellectual property or proprietary rights laws.
            </p>
            <p>
              These Terms permit you to use the Service for your personal, non-commercial use only. You must not reproduce, distribute, 
              modify, create derivative works of, publicly display, publicly perform, republish, download, store, or transmit any of 
              the material on our Service, except as follows:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li>Your computer may temporarily store copies of such materials in RAM incidental to your accessing and viewing those materials.</li>
              <li>You may store files that are automatically cached by your Web browser for display enhancement purposes.</li>
              <li>You may print or download one copy of a reasonable number of pages of the Service for your own personal, 
                non-commercial use and not for further reproduction, publication, or distribution.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">5. User Content</h2>
            <p>
              The Service allows you to create and store content such as invoice data, business information, and client details 
              ("User Content"). You retain all rights in, and are solely responsible for, the User Content you create, upload, 
              post, send, or store through the Service.
            </p>
            <p>
              By providing User Content through the Service, you grant us a worldwide, non-exclusive, royalty-free license to use, 
              copy, process, and store your User Content in connection with providing the Service to you.
            </p>
            <p>
              You represent and warrant that:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li>You own or control all rights in and to the User Content and have the right to grant the license granted above.</li>
              <li>All of your User Content does and will comply with these Terms.</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">6. Privacy</h2>
            <p>
              Your use of the Service is also governed by our Privacy Policy, which is incorporated into these Terms by reference. 
              Please review our Privacy Policy to understand our practices regarding your personal information.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">7. Changes to the Terms</h2>
            <p>
              We may revise and update these Terms from time to time at our sole discretion. All changes are effective immediately 
              when we post them, and apply to all access to and use of the Service thereafter.
            </p>
            <p>
              Your continued use of the Service following the posting of revised Terms means that you accept and agree to the changes. 
              It is your responsibility to check this page periodically for changes.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">8. Disclaimer of Warranties</h2>
            <p>
              THE SERVICE IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, 
              EITHER EXPRESS OR IMPLIED. NEITHER DUE CLEAR NOR ANY PERSON ASSOCIATED WITH DUE CLEAR MAKES ANY WARRANTY OR 
              REPRESENTATION WITH RESPECT TO THE COMPLETENESS, SECURITY, RELIABILITY, QUALITY, ACCURACY, OR AVAILABILITY OF THE SERVICE.
            </p>
            <p>
              THE FOREGOING DOES NOT AFFECT ANY WARRANTIES WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">9. Limitation of Liability</h2>
            <p>
              IN NO EVENT WILL DUE CLEAR, ITS AFFILIATES, OR THEIR LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS, 
              OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR 
              USE, OR INABILITY TO USE, THE SERVICE, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR 
              PUNITIVE DAMAGES.
            </p>
            <p>
              THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">10. Governing Law</h2>
            <p>
              These Terms and any dispute or claim arising out of or in connection with them or their subject matter or formation 
              shall be governed by and construed in accordance with the law of [Your Jurisdiction], without giving effect to any 
              choice or conflict of law provision or rule.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">11. Contact Information</h2>
            <p>
              If you have any questions about these Terms, please contact us at:
            </p>
            <p>
              Email: support@dueclear.com<br />
              Address: 123 Invoice Street, Suite 456, Billing City, BC 78901
            </p>
          </section>
        </div>
      </main>
      
      <PageFooter />
    </div>
  );
}