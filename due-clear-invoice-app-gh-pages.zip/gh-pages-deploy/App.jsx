import React from 'react';
import { Route, Switch } from 'wouter';
import { Toaster } from './components/ui/toaster';

// Import pages
import Home from './pages/Home';
import InvoiceForm from './components/InvoiceForm';
import InvoiceDetails from './pages/InvoiceDetails';
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';
import HelpCenter from './pages/HelpCenter';
import InvoicingGuide from './pages/InvoicingGuide';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import NotFound from './pages/not-found';
import PageHeader from './components/PageHeader';
import PageFooter from './components/PageFooter';

// Router component for handling routes
function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/create-invoice" component={InvoiceForm} />
      <Route path="/invoices/:id">
        {params => <InvoiceDetails id={params.id} />}
      </Route>
      <Route path="/about-us" component={AboutUs} />
      <Route path="/contact-us" component={ContactUs} />
      <Route path="/help-center" component={HelpCenter} />
      <Route path="/invoicing-guide" component={InvoicingGuide} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/terms-of-service" component={TermsOfService} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader />
      <main className="flex-grow container mx-auto px-4 py-6">
        <Router />
      </main>
      <PageFooter />
      <Toaster />
    </div>
  );
}

export default App;
