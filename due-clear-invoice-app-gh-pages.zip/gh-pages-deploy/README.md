# Due Clear Invoice App - GitHub Pages Version

## Deployment Instructions

### Option 1: Quick Deploy to GitHub Pages

1. **Create a new repository on GitHub**
   - Go to https://github.com/new
   - Name your repository (e.g., "due-clear-invoice")
   - Make it public
   - Click "Create repository"

2. **Upload these files to your repository**
   - Click "uploading an existing file" on the repository page
   - Drag and drop all files from this folder
   - Commit the changes

3. **Setup GitHub Pages**
   - Go to repository Settings > Pages
   - Under "Source", select "Deploy from a branch"
   - Select the branch (usually "main")
   - Select folder "/" (root)
   - Click "Save"

4. **Your app will be available at**:
   - https://[your-username].github.io/[repository-name]/

### Option 2: For Developers - Clone and Deploy

```bash
# Clone the repository
git clone https://github.com/[your-username]/[repository-name].git
cd [repository-name]

# If you want to make changes, edit the files
# Then commit and push your changes
git add .
git commit -m "Update invoice app"
git push origin main
```

## Features

- Create and manage invoices directly in your browser
- No server needed - all data is stored in your browser's local storage
- Generate invoice PDFs
- Fully responsive design for mobile and desktop

## Important Notes

- This is a client-side only application
- Your data is stored in your browser's local storage and won't be accessible from other devices
- If you clear your browser data, your invoices will be lost

## Customization

You can customize this app by editing the following files:
- `index.html` - Main HTML structure
- `style.css` - CSS styling
- `index.js` - Main application logic
- `utils.js` - Utility functions

## Need Help?

If you need help with deployment or customization, contact us at: cryptoman3101@gmail.com
