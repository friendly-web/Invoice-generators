import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useLocation } from 'wouter';
import { nanoid } from 'nanoid';

// UI Components
import { Form } from './components/ui/form';
import { Button } from './components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card, CardContent } from './components/ui/card';
import { useToast } from './hooks/use-toast';

// Custom Components
import LogoUpload from './components/LogoUpload';
import InvoicePreview from './components/InvoicePreview';

// Constants and utils
import { PAYMENT_TERMS, PAYMENT_METHODS, CURRENCIES } from './lib/constants';
import { invoiceFormSchema } from './schema';
import { calculateDueDate, generateInvoiceNumber } from './lib/utils';

// Static API
import { createInvoice } from './apiAdapter';

export default function InvoiceForm() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview, setLogoPreview] = useState(null);
  const [currentTab, setCurrentTab] = useState('details');
  const [items, setItems] = useState([]);
  
  // Form setup
  const form = useForm({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      invoiceNumber: '',
      paymentTerms: 'net_30',
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: calculateDueDate(new Date().toISOString().split('T')[0], 'net_30'),
      currency: 'USD',
      businessDetails: '',
      clientDetails: '',
      paymentMethod: 'bank_transfer',
      items: [],
      totalAmount: 0,
      subtotal: 0,
      discountTotal: 0,
      tax: 0,
      shipping: 0,
    },
  });

  const { watch, setValue, handleSubmit, formState } = form;
  const formValues = watch();

  // Watch for payment terms changes to update due date
  const paymentTerms = watch('paymentTerms');
  const issueDate = watch('issueDate');
  
  React.useEffect(() => {
    if (issueDate && paymentTerms) {
      setValue('dueDate', calculateDueDate(issueDate, paymentTerms));
    }
  }, [paymentTerms, issueDate, setValue]);

  // Handle logo upload
  const handleLogoChange = (file) => {
    setLogoFile(file);
    
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setLogoPreview(null);
    }
  };

  // Handle form submission
  const onSubmit = async (data) => {
    try {
      // Calculate totals
      const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
      const discountTotal = items.reduce(
        (sum, item) => sum + (item.amount * item.discount) / 100,
        0
      );
      const totalAmount = subtotal - discountTotal + (data.tax || 0) + (data.shipping || 0);

      // Prepare final data
      const invoiceData = {
        ...data,
        items,
        subtotal,
        discountTotal,
        totalAmount: Math.round(totalAmount * 100) / 100,
        logoUrl: logoPreview,
      };

      // Create invoice
      const newInvoice = await createInvoice(invoiceData);
      
      toast({
        title: 'Success!',
        description: `Invoice ${newInvoice.invoiceNumber} has been created`,
      });

      // Navigate to the new invoice page
      navigate(`/invoices/${newInvoice.id}`);
    } catch (error) {
      console.error('Error creating invoice:', error);
      toast({
        title: 'Error',
        description: 'Failed to create invoice. Please try again.',
        variant: 'destructive',
      });
    }
  };

  // Handle adding new items
  const handleAddItem = () => {
    const newItem = {
      id: nanoid(),
      description: '',
      quantity: 1,
      rate: 0,
      discount: 0,
      amount: 0,
    };
    
    setItems([...items, newItem]);
  };

  // Handle updating items
  const handleUpdateItem = (id, field, value) => {
    const updatedItems = items.map((item) => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        
        // Recalculate amount when quantity, rate, or discount changes
        if (field === 'quantity' || field === 'rate') {
          updatedItem.amount = updatedItem.quantity * updatedItem.rate;
        }
        
        return updatedItem;
      }
      return item;
    });
    
    setItems(updatedItems);
  };

  // Handle removing items
  const handleRemoveItem = (id) => {
    setItems(items.filter((item) => item.id !== id));
  };

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const discountTotal = items.reduce(
    (sum, item) => sum + (item.amount * item.discount) / 100,
    0
  );
  const tax = formValues.tax || 0;
  const shipping = formValues.shipping || 0;
  const total = subtotal - discountTotal + tax + shipping;

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">Create Invoice</h1>
      
      <Tabs value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="details">Invoice Details</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>
        
        <TabsContent value="details" className="space-y-6">
          <Form {...form}>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              {/* Logo Upload */}
              <Card>
                <CardContent className="pt-6">
                  <LogoUpload
                    logoPreview={logoPreview}
                    onChange={handleLogoChange}
                  />
                </CardContent>
              </Card>
              
              {/* Invoice Details */}
              <Card>
                <CardContent className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Invoice Number */}
                  <div className="space-y-2">
                    <label htmlFor="invoiceNumber" className="text-sm font-medium">
                      Invoice Number
                    </label>
                    <input
                      id="invoiceNumber"
                      type="text"
                      className="w-full p-2 border rounded-md"
                      placeholder="Invoice Number"
                      {...form.register('invoiceNumber')}
                    />
                    {formState.errors.invoiceNumber && (
                      <p className="text-sm text-red-500">
                        {formState.errors.invoiceNumber.message}
                      </p>
                    )}
                  </div>
                  
                  {/* Payment Terms */}
                  <div className="space-y-2">
                    <label htmlFor="paymentTerms" className="text-sm font-medium">
                      Payment Terms
                    </label>
                    <select
                      id="paymentTerms"
                      className="w-full p-2 border rounded-md"
                      {...form.register('paymentTerms')}
                    >
                      {PAYMENT_TERMS.map((term) => (
                        <option key={term.value} value={term.value}>
                          {term.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  {/* Issue Date */}
                  <div className="space-y-2">
                    <label htmlFor="issueDate" className="text-sm font-medium">
                      Issue Date
                    </label>
                    <input
                      id="issueDate"
                      type="date"
                      className="w-full p-2 border rounded-md"
                      {...form.register('issueDate')}
                    />
                  </div>
                  
                  {/* Due Date */}
                  <div className="space-y-2">
                    <label htmlFor="dueDate" className="text-sm font-medium">
                      Due Date
                    </label>
                    <input
                      id="dueDate"
                      type="date"
                      className="w-full p-2 border rounded-md"
                      {...form.register('dueDate')}
                      readOnly
                    />
                  </div>
                  
                  {/* Currency */}
                  <div className="space-y-2">
                    <label htmlFor="currency" className="text-sm font-medium">
                      Currency
                    </label>
                    <select
                      id="currency"
                      className="w-full p-2 border rounded-md"
                      {...form.register('currency')}
                    >
                      {CURRENCIES.map((currency) => (
                        <option key={currency.value} value={currency.value}>
                          {currency.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </CardContent>
              </Card>
              
              {/* Business & Client Details */}
              <Card>
                <CardContent className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Business Details */}
                  <div className="space-y-2">
                    <label htmlFor="businessDetails" className="text-sm font-medium">
                      Business Details
                    </label>
                    <textarea
                      id="businessDetails"
                      className="w-full p-2 border rounded-md min-h-[150px]"
                      placeholder="Your Business Name\nAddress\nCity, State, ZIP\nCountry\nPhone\nEmail"
                      {...form.register('businessDetails')}
                    />
                  </div>
                  
                  {/* Client Details */}
                  <div className="space-y-2">
                    <label htmlFor="clientDetails" className="text-sm font-medium">
                      Client Details
                    </label>
                    <textarea
                      id="clientDetails"
                      className="w-full p-2 border rounded-md min-h-[150px]"
                      placeholder="Client Business Name\nContact Person\nAddress\nCity, State, ZIP\nCountry\nPhone\nEmail"
                      {...form.register('clientDetails')}
                    />
                  </div>
                </CardContent>
              </Card>
              
              {/* Invoice Items */}
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Invoice Items</h3>
                  
                  {/* Items Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Description</th>
                          <th className="text-left p-2">Qty</th>
                          <th className="text-left p-2">Rate</th>
                          <th className="text-left p-2">Discount %</th>
                          <th className="text-left p-2">Amount</th>
                          <th className="text-left p-2">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {items.map((item) => (
                          <tr key={item.id} className="border-b">
                            <td className="p-2">
                              <input
                                type="text"
                                className="w-full p-2 border rounded-md"
                                value={item.description}
                                onChange={(e) =>
                                  handleUpdateItem(item.id, 'description', e.target.value)
                                }
                                placeholder="Item description"
                              />
                            </td>
                            <td className="p-2">
                              <input
                                type="number"
                                className="w-full p-2 border rounded-md"
                                value={item.quantity}
                                onChange={(e) =>
                                  handleUpdateItem(
                                    item.id,
                                    'quantity',
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                min="1"
                              />
                            </td>
                            <td className="p-2">
                              <input
                                type="number"
                                className="w-full p-2 border rounded-md"
                                value={item.rate}
                                onChange={(e) =>
                                  handleUpdateItem(
                                    item.id,
                                    'rate',
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                min="0"
                                step="0.01"
                              />
                            </td>
                            <td className="p-2">
                              <input
                                type="number"
                                className="w-full p-2 border rounded-md"
                                value={item.discount}
                                onChange={(e) =>
                                  handleUpdateItem(
                                    item.id,
                                    'discount',
                                    parseFloat(e.target.value) || 0
                                  )
                                }
                                min="0"
                                max="100"
                              />
                            </td>
                            <td className="p-2 text-right">
                              {(item.amount || 0).toFixed(2)}
                            </td>
                            <td className="p-2">
                              <Button
                                type="button"
                                variant="destructive"
                                size="sm"
                                onClick={() => handleRemoveItem(item.id)}
                              >
                                Remove
                              </Button>
                            </td>
                          </tr>
                        ))}
                        {items.length === 0 && (
                          <tr>
                            <td colSpan="6" className="p-4 text-center text-muted-foreground">
                              No items added. Click "Add Item" to add an invoice item.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                  
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleAddItem}
                    className="mt-2"
                  >
                    Add Item
                  </Button>
                  
                  {/* Totals */}
                  <div className="space-y-2 pt-4 border-t mt-6">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>{subtotal.toFixed(2)}</span>
                    </div>
                    {discountTotal > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>Discount</span>
                        <span>-{discountTotal.toFixed(2)}</span>
                      </div>
                    )}
                    
                    {/* Tax */}
                    <div className="flex justify-between items-center">
                      <span>Tax</span>
                      <input
                        type="number"
                        className="w-20 p-1 border rounded-md text-right"
                        value={formValues.tax || ''}
                        onChange={(e) => setValue('tax', parseFloat(e.target.value) || 0)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    
                    {/* Shipping */}
                    <div className="flex justify-between items-center">
                      <span>Shipping</span>
                      <input
                        type="number"
                        className="w-20 p-1 border rounded-md text-right"
                        value={formValues.shipping || ''}
                        onChange={(e) =>
                          setValue('shipping', parseFloat(e.target.value) || 0)
                        }
                        min="0"
                        step="0.01"
                      />
                    </div>
                    
                    <div className="flex justify-between font-bold text-lg pt-2 border-t">
                      <span>Total</span>
                      <span>{total.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Payment Method */}
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Payment Method</h3>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label htmlFor="paymentMethod" className="text-sm font-medium">
                        Payment Method
                      </label>
                      <select
                        id="paymentMethod"
                        className="w-full p-2 border rounded-md"
                        {...form.register('paymentMethod')}
                      >
                        {PAYMENT_METHODS.map((method) => (
                          <option key={method.value} value={method.value}>
                            {method.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    {formValues.paymentMethod === 'bank_transfer' && (
                      <div className="space-y-2">
                        <label htmlFor="bankDetails" className="text-sm font-medium">
                          Bank Details
                        </label>
                        <textarea
                          id="bankDetails"
                          className="w-full p-2 border rounded-md min-h-[100px]"
                          placeholder="Bank Name\nAccount Name\nAccount Number\nRouting Number\nSWIFT/BIC"
                          {...form.register('bankDetails')}
                        />
                      </div>
                    )}
                    
                    {formValues.paymentMethod === 'paypal' && (
                      <div className="space-y-2">
                        <label htmlFor="paypalDetails" className="text-sm font-medium">
                          PayPal Details
                        </label>
                        <textarea
                          id="paypalDetails"
                          className="w-full p-2 border rounded-md min-h-[100px]"
                          placeholder="PayPal Email\nPayPal.me Link"
                          {...form.register('paypalDetails')}
                        />
                      </div>
                    )}
                    
                    {formValues.paymentMethod === 'upi' && (
                      <div className="space-y-2">
                        <label htmlFor="upiDetails" className="text-sm font-medium">
                          UPI Details
                        </label>
                        <textarea
                          id="upiDetails"
                          className="w-full p-2 border rounded-md min-h-[100px]"
                          placeholder="UPI ID\nQR Code Link (optional)"
                          {...form.register('upiDetails')}
                        />
                      </div>
                    )}
                    
                    {formValues.paymentMethod === 'payment_link' && (
                      <div className="space-y-2">
                        <label
                          htmlFor="paymentLinkDetails"
                          className="text-sm font-medium"
                        >
                          Payment Link Details
                        </label>
                        <textarea
                          id="paymentLinkDetails"
                          className="w-full p-2 border rounded-md min-h-[100px]"
                          placeholder="Payment URL\nInstructions (optional)"
                          {...form.register('paymentLinkDetails')}
                        />
                      </div>
                    )}
                    
                    {formValues.paymentMethod === 'cash' && (
                      <div className="space-y-2">
                        <label htmlFor="cashDetails" className="text-sm font-medium">
                          Cash Payment Instructions
                        </label>
                        <textarea
                          id="cashDetails"
                          className="w-full p-2 border rounded-md min-h-[100px]"
                          placeholder="Cash payment instructions"
                          {...form.register('cashDetails')}
                        />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {/* Notes & Terms */}
              <Card>
                <CardContent className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="notes" className="text-sm font-medium">
                      Notes
                    </label>
                    <textarea
                      id="notes"
                      className="w-full p-2 border rounded-md min-h-[100px]"
                      placeholder="Notes to the client"
                      {...form.register('notes')}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="terms" className="text-sm font-medium">
                      Terms & Conditions
                    </label>
                    <textarea
                      id="terms"
                      className="w-full p-2 border rounded-md min-h-[100px]"
                      placeholder="Terms and conditions"
                      {...form.register('terms')}
                    />
                  </div>
                </CardContent>
              </Card>
              
              {/* Submit Button */}
              <div className="flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCurrentTab('preview')}
                >
                  Preview
                </Button>
                <Button type="submit" disabled={formState.isSubmitting}>
                  {formState.isSubmitting ? 'Creating...' : 'Create Invoice'}
                </Button>
              </div>
            </form>
          </Form>
        </TabsContent>
        
        <TabsContent value="preview">
          <div className="space-y-6">
            <Card>
              <CardContent className="pt-6">
                <InvoicePreview
                  invoice={{
                    ...formValues,
                    items,
                    subtotal,
                    discountTotal,
                    totalAmount: total,
                  }}
                  logoPreview={logoPreview}
                />
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setCurrentTab('details')}>
                Back to Edit
              </Button>
              <Button onClick={handleSubmit(onSubmit)} disabled={formState.isSubmitting}>
                {formState.isSubmitting ? 'Creating...' : 'Create Invoice'}
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
