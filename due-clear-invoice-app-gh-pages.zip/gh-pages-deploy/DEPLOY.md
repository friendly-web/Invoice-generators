# Deployment Guide for GitHub Pages

1. Create a new repository on GitHub named `due-clear`
2. Push the contents of this folder to the repository
3. Go to Settings > Pages
4. Set the Source to "Deploy from a branch"
5. Select the "main" branch and "/root" folder
6. Click Save
7. Your site will be published at https://yourusername.github.io/due-clear/
