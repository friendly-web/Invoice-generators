import { z } from 'zod';

// Invoice Items Schema
export const invoiceItemSchema = z.object({
  id: z.string(),
  description: z.string().min(1, 'Description is required'),
  quantity: z.number().min(1, 'Quantity must be at least 1'),
  rate: z.number().min(0, 'Rate must be a positive number'),
  discount: z.number().min(0, 'Discount must be a positive number').max(100, 'Discount cannot exceed 100%'),
  amount: z.number(),
});

export const invoiceFormSchema = z.object({
  invoiceNumber: z.string().min(1, 'Invoice number is required'),
  paymentTerms: z.string().min(1, 'Payment terms are required'),
  issueDate: z.string().min(1, 'Issue date is required'),
  dueDate: z.string().min(1, 'Due date is required'),
  currency: z.string().min(1, 'Currency is required'),
  logoUrl: z.string().optional(),
  
  // Business details
  businessDetails: z.string().optional(),
  
  // Client details
  clientDetails: z.string().optional(),
  
  // Payment details
  paymentMethod: z.string().default('bank_transfer'),
  bankDetails: z.string().optional(),
  paypalDetails: z.string().optional(),
  upiDetails: z.string().optional(),
  paymentLinkDetails: z.string().optional(),
  cashDetails: z.string().optional(),
  
  // Notes and terms
  notes: z.string().optional(),
  terms: z.string().optional(),
  
  // Invoice totals
  totalAmount: z.number().default(0),
  subtotal: z.number().default(0),
  discountTotal: z.number().default(0),
  tax: z.number().default(0),
  shipping: z.number().default(0),
  
  // Invoice items
  items: z.array(invoiceItemSchema).optional(),
});

export const PAYMENT_TERMS = [
  { value: 'due_on_receipt', label: 'Due on Receipt' },
  { value: 'net_7', label: 'Net 7 Days' },
  { value: 'net_15', label: 'Net 15 Days' },
  { value: 'net_30', label: 'Net 30 Days' },
  { value: 'net_45', label: 'Net 45 Days' },
  { value: 'net_60', label: 'Net 60 Days' },
  { value: 'custom', label: 'Custom' },
];

export const PAYMENT_METHODS = [
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'paypal', label: 'PayPal' },
  { value: 'upi', label: 'UPI' },
  { value: 'payment_link', label: 'Payment Link' },
  { value: 'cash', label: 'Cash' },
];

export const CURRENCIES = [
  { value: 'USD', label: 'USD - US Dollar' },
  { value: 'EUR', label: 'EUR - Euro' },
  { value: 'GBP', label: 'GBP - British Pound' },
  { value: 'INR', label: 'INR - Indian Rupee' },
  { value: 'JPY', label: 'JPY - Japanese Yen' },
  { value: 'CAD', label: 'CAD - Canadian Dollar' },
  { value: 'AUD', label: 'AUD - Australian Dollar' },
  { value: 'SGD', label: 'SGD - Singapore Dollar' },
  { value: 'AED', label: 'AED - UAE Dirham' },
  { value: 'CNY', label: 'CNY - Chinese Yuan' },
];
