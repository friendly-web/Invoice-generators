// Due Clear Invoice App - GitHub Pages Version
// This file bundles all the necessary code for the static GitHub Pages deployment

// Static API implementation using localStorage
class StaticApiAdapter {
  constructor() {
    // Initialize localStorage if needed
    if (!localStorage.getItem('invoices')) {
      localStorage.setItem('invoices', JSON.stringify([]));
    }
    
    // Initialize counter for invoice IDs
    if (!localStorage.getItem('nextInvoiceId')) {
      localStorage.setItem('nextInvoiceId', '1');
    }
  }

  // Get all invoices
  async getInvoices() {
    return JSON.parse(localStorage.getItem('invoices') || '[]');
  }

  // Get a specific invoice
  async getInvoice(id) {
    const invoices = await this.getInvoices();
    return invoices.find(invoice => invoice.id === Number(id));
  }

  // Create a new invoice
  async createInvoice(invoice) {
    const invoices = await this.getInvoices();
    const nextId = Number(localStorage.getItem('nextInvoiceId'));
    
    const newInvoice = {
      ...invoice,
      id: nextId,
      createdAt: new Date().toISOString()
    };
    
    invoices.push(newInvoice);
    localStorage.setItem('invoices', JSON.stringify(invoices));
    localStorage.setItem('nextInvoiceId', String(nextId + 1));
    
    return newInvoice;
  }

  // Update an existing invoice
  async updateInvoice(id, invoice) {
    const invoices = await this.getInvoices();
    const index = invoices.findIndex(inv => inv.id === Number(id));
    
    if (index >= 0) {
      invoices[index] = { ...invoices[index], ...invoice };
      localStorage.setItem('invoices', JSON.stringify(invoices));
      return invoices[index];
    }
    
    return null;
  }

  // Delete an invoice
  async deleteInvoice(id) {
    const invoices = await this.getInvoices();
    const filteredInvoices = invoices.filter(invoice => invoice.id !== Number(id));
    
    localStorage.setItem('invoices', JSON.stringify(filteredInvoices));
    return true;
  }

  // Upload logo (stores as base64)
  async uploadLogo(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }
}

// Export the API functions
const staticApi = new StaticApiAdapter();

export async function uploadLogo(file) {
  return staticApi.uploadLogo(file);
}

export async function createInvoice(invoice) {
  return staticApi.createInvoice(invoice);
}

export async function updateInvoice(id, invoice) {
  return staticApi.updateInvoice(id, invoice);
}

export async function fetchInvoice(id) {
  return staticApi.getInvoice(id);
}

export async function fetchInvoices() {
  return staticApi.getInvoices();
}

export async function deleteInvoice(id) {
  return staticApi.deleteInvoice(id);
}

export async function generateInvoicePDF(invoice, logoDataUrl) {
  // Client-side PDF generation would be implemented here
  console.log('Generating PDF for invoice:', invoice.id);
  alert('PDF generation in GitHub Pages static deployment is limited. Please use a PDF generation library in your integration.');
  return 'data:application/pdf;base64,JVBERi0xLjcKJcQxw...';
}

export async function sendInvoiceEmail(invoiceId, emailData) {
  // Email sending is not available in static deployment
  alert('Email functionality is not available in this static deployment. Please download the PDF and send it manually.');
  return { success: true, message: 'Email simulation completed' };
}
