// Utility functions for the Due Clear Invoice App

export function formatDate(date) {
  if (!date) return '';
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}

export function calculateDueDate(issueDate, paymentTerms) {
  if (!issueDate) return '';
  
  const date = new Date(issueDate);
  
  switch (paymentTerms) {
    case 'due_on_receipt':
      return issueDate;
    case 'net_7':
      date.setDate(date.getDate() + 7);
      break;
    case 'net_15':
      date.setDate(date.getDate() + 15);
      break;
    case 'net_30':
      date.setDate(date.getDate() + 30);
      break;
    case 'net_45':
      date.setDate(date.getDate() + 45);
      break;
    case 'net_60':
      date.setDate(date.getDate() + 60);
      break;
    default:
      return issueDate;
  }
  
  return date.toISOString().split('T')[0];
}

export function getFormattedCurrency(currency) {
  const currencyMap = {
    USD: '$',
    EUR: '€',
    GBP: '£',
    INR: '₹',
    JPY: '¥',
    CAD: 'CA$',
    AUD: 'A$',
    SGD: 'S$',
    AED: 'د.إ',
    CNY: '¥'
  };
  
  return currencyMap[currency] || currency;
}

export function generateInvoiceNumber(prefix = 'INV', num = 1) {
  const paddedNum = String(num).padStart(5, '0');
  return `${prefix}-${paddedNum}`;
}

export function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
